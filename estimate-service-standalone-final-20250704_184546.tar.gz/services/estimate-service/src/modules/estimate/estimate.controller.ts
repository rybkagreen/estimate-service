import { Controller } from '@nestjs/common';

@Controller('estimates')
export class EstimateController {
  // Define endpoints here
}
