import { Injectable } from '@nestjs/common';

@Injectable()
export class EstimateService {
  // Define business logic here
}
