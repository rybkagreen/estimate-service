import { Module } from '@nestjs/common';

@Module({
  // TODO: Implement Grand Smeta export module
})
export class GrandSmetaModule {}
