import { Module } from '@nestjs/common';

@Module({
  // TODO: Implement validation module
})
export class ValidationModule {}
