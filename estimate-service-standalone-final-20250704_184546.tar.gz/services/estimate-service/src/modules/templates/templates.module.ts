import { Module } from '@nestjs/common';

@Module({
  // TODO: Implement templates module
})
export class TemplatesModule {}
