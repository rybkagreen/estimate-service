import { Module } from '@nestjs/common';

@Module({
  // TODO: Implement classification module
})
export class ClassificationModule {}
